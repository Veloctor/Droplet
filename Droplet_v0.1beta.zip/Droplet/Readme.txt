本作品(三体水滴mod)基于以下作品运行:
CommunityResourcePack	作者为RoverDude(KerbalForum);
GNdrive			作者为flywlyx(百度贴吧).

This product(Threebody Droplet mod)is based on following products:
CommunityResourcePack	Author:	RoverDude(KerbalForum);
GNdrive			Author:	flywlyx(Baidu Tieba).

分享请遵循CC-BY-NC-SA 4.0协议